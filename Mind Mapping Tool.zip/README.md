
  # Mind Mapping Tool

  This is a code bundle for Mind Mapping Tool. The original project is available at https://www.figma.com/design/57dHmVXvYIpwY506JGxfTY/Mind-Mapping-Tool.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  